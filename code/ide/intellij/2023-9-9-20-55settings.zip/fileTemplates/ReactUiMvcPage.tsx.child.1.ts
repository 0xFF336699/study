import {EventDispatcher} from "../../../../events/EventDispatcher";
import {PropertyChangeEvent} from "../../../../events/PropertyChangeEvent";

export class ${name}PageModel extends EventDispatcher{
    constructor() {
        super();
    }
    init = ()=>{

    }

}
export interface IParams{

}
export const model = new ${name}PageModel();