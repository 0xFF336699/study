#if (${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

import com.chanxiaojian.expresshouse.net.Member;
import com.chanxiaojian.expresshouse.utils.ThreadUtil;
import com.chanxiaojian.expresshouse.net.TMs;
import com.chanxiaojian.expresshouse.utils.ToastUtil;
import com.chanxiaojian.expresshouse.vo.teams.MemberResultBase;
import com.shangwoa.events.DataEvent;
import com.shangwoa.events.IListener;

#if (${IMPORT_BLOCK} != "")${IMPORT_BLOCK}
        #end
        #parse("File Header.java")
        #if (${VISIBILITY} == "PUBLIC")public #end #if (${ABSTRACT} == "TRUE")abstract #end #if (${FINAL} == "TRUE")final #end class ${NAME} #if (${INTERFACES} != "")implements ${INTERFACES} #end {
    private static final ${NAME} instance = new ${NAME}();
    public static final ${NAME} getInstance(){return instance;}
}
