import {ComponentBase} from "../components/ComponentBase";
import PropertyChangeEvent from "../../../../events/PropertyChangeEvent";
import {IParams, model, ${name}PageModel} from "./${name}PageModel";
import {Page, PageContent, Row} from "framework7-react";

let page:${name}Page;
export function getPage():${name}Page{
    return page;
}
export class ${name}Page extends ComponentBase{
    private _eventsInitialized:boolean = false;
    constructor(props) {
        super(props);
        this.state = {params:null};
        page = this;
        this.dispatcher.addEventListener(ComponentBase.eventIsMountedChanged, this._onMounted);
    }
    setParams = (params:IParams)=>{
        this.setState({params})
    }
    _onAdded = ()=>{
        page = this;
        this._addEvents();
    }
    _onRemoved = ()=>{
        this._removeEvents();
    }
    _addEvents = ()=>{
        if(this._eventsInitialized)return;
        this._eventsInitialized = true;
    }
    _removeEvents = ()=>{
        if(!this._eventsInitialized)return;
        this._eventsInitialized = false;
    }
    _onMounted = (e:PropertyChangeEvent<boolean>)=>{
        if(e.newValue){
            this._onAdded();
        }else{
            this._onRemoved();
        }
    }
    render = () =>{
        return <Page pageContent={false}>
            <div className="navbar">
                <div className="navbar-bg"></div>
                <div className="navbar-inner sliding" style={{flexDirection:"row"}}>
                    <a className="link back">
                        <i className="icon icon-back"></i>
                        <span className="if-not-md">返回</span>
                    </a>
                </div>
            </div>
            <PageContent style={{paddingTop:"0px"}}>
                
            </PageContent>
        </Page>
    }
}