import {ComponentBase} from "../../../libs/fanfanlo/react/components/ComponentBase";
import {Navbar, Page, PageContent} from "framework7-react";
import React from 'react';
import TMs from "../../remotes/TMs";
import {Member} from "../../../libs/fanfanlo/remotes/Member";
import {Event2} from "../../../libs/fanfanlo/events/Event2";
import {MainModel, mainModel} from "../../mc/MainModel";
#set($upper = ${StringUtils.removeAndHump($name, "-")})
#set($lower = $upper.substring(0,1).toLowerCase() + $upper.substring(1))
export class ${upper}Content extends ComponentBase {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <>

            </>
        )
    }
}
export class ${upper} extends ComponentBase {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <Page pageContent={false} className={"no-toolbar"}>
                <Navbar title={${lower}Router.name} backLink="返回"/>
                <PageContent>
                    <${upper}Content />
                </PageContent>
            </Page>
        )
    }
}
export const ${lower}Router = {
    id:"${name}",
    p:"/${name}/",
    path:"/${name}/",
    component:${upper},
    name:"授权操作"
}
